# Formative 1
This first lab exercise is a formative one. Formative means that it is not awarded marks that count towards the module outcome.

The purpose of this lab is to ensure that you know enough about markdown to be able to record your results for the following summative challenges.

You can edit the [Practice Page](PracticePage.md) to ensure that you understand markdown.

## Executing a test plan

As part of the first lab exercises you need to compile some code and test it. You can record the results of the tests here.

