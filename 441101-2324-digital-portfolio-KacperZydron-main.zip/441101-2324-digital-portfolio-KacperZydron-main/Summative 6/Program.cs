// This statement is including the System namespace, which contains fundamental types and base classes.
using System;

// This defines the Circle class.

// private static int nextId = 1;: A private static variable nextId is used to keep track of unique IDs for each circle. It starts from 1 and increments with each new circle.

// public int Id { get; private set; }: This is a property Id with a public getter and private setter. It represents the unique ID of the circle.

// public double Radius { get; private set; }: This is a property Radius with a public getter and private setter.It represents the radius of the circle.

// public Circle(double radius = 1): This is the constructor of the Circle class. It takes an optional parameter radius with a default value of 1. It assigns a unique ID to the circle and sets the radius using the SetRadius method.

// public void SetRadius(double radius): This method sets the radius of the circle with validation to ensure it's not negative.

// public double CalculateArea(): This method calculates and returns the area of the circle using the formula ?r�.

// public double CalculateCircumference(): This method calculates and returns the circumference of the circle using the formula 2?r.
class Circle
{
    // Class variable to keep track of unique IDs
    private static int nextId = 1;

    public int Id { get; private set; }
    public double Radius { get; private set; }

    // Constructor with optional radius parameter (default value of 1)
    public Circle(double radius = 1)
    {
        Id = nextId++;
        SetRadius(radius);
    }

    // Method to set the radius with validation
    public void SetRadius(double radius)
    {
        // Ensure radius is not negative
        if (radius >= 0)
        {
            Radius = radius;
        }
        else
        {
            Console.WriteLine("Error: Radius cannot be negative. Setting radius to 0.");
            Radius = 0;
        }
    }

    // Method to calculate the area of the circle
    public double CalculateArea()
    {
        return Math.PI * Math.Pow(Radius, 2);
    }

    // Method to calculate the circumference of the circle
    public double CalculateCircumference()
    {
        return 2 * Math.PI * Radius;
    }
}
// This is a separate class containing the Main method, which serves as the entry point of the program.

// static void Main(): This is the Main method where the testing of the Circle class is done.
class Program
{
    // Circle circle1 = new Circle(5);: Creates a circle with a specified radius of 5.

    // Circle circle2 = new Circle();: Creates a circle with the default radius of 1.

    // circle2.SetRadius(3);: Changes the radius of circle2 to 3.

    // Console.WriteLine(...): Outputs information about each circle, including its ID, radius, area, and circumference.
    static void Main()
    {
        // Testing the Circle class
        Circle circle1 = new Circle(5);
        Console.WriteLine($"Circle {circle1.Id}: Radius = {circle1.Radius}, Area = {circle1.CalculateArea()}, Circumference = {circle1.CalculateCircumference()}");

        Circle circle2 = new Circle(); // Default radius of 1
        Console.WriteLine($"Circle {circle2.Id}: Radius = {circle2.Radius}, Area = {circle2.CalculateArea()}, Circumference = {circle2.CalculateCircumference()}");

        // Change the radius of circle2
        circle2.SetRadius(3);
        Console.WriteLine($"Circle {circle2.Id}: Radius = {circle2.Radius}, Area = {circle2.CalculateArea()}, Circumference = {circle2.CalculateCircumference()}");
    }
}

