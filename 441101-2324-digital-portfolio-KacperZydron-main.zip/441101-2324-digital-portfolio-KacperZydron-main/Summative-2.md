# Summative 2

## Challenge Description

Include a decription of the challenge here.

## Code Listing

```cs
// Include your C# solution code here
```

## Test Plan

Include your test plan and results here

| Test Number | Input | Expected Output | Actual Output |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |

## Feedback Request

If there is anything specific you want to ask for feedback on include that here
