# 441101-2324-Digital-Portfolio

This digital portfolio is where you will record your summative work (summative means that it is awarded marks that count towards the module outcome).

For each summative assignment you will solve a small problem and record your results in the pages that are linked below.

Then during the appropriate lab session you will talk about your solution with a feedback engineer, and get feedback on your progress.

## Index of links to summative assignments

[Summative 1](Summative-1.md)

[Summative 2](Summative-2.md)

[Summative 3](Summative-3.md)

[Summative 4](Summative-4.md)

[Summative 5](Summative-5.md)

[Summative 6](Summative-6.md)

[Summative 7](Summative-7.md)

[Summative 8](Summative-8.md)
