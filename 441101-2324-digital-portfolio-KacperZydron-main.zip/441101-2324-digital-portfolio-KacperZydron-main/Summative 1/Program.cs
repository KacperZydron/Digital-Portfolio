﻿// This line includes the System namespace, which contains fundamental types and the Console class used for input and output operations.
using System;

// This declares a class named CarHireProgram and defines the Main method, which serves as the entry point for the program.
class CarHireProgram
{
    static void Main()
    {
        // The try block is used to handle potential exceptions. It prompts the user to enter the number of days the car was hired for and the litres of fuel left in the tank. Console.ReadLine() is used to read the input as strings, and int.Parse() and double.Parse() are used for converting those strings to int and double, respectively.
        try
        {
            // Get user input for days hired and litres of fuel left
            Console.Write("Enter the number of days the car was hired for: ");
            int daysHired = int.Parse(Console.ReadLine());

            Console.Write("Enter the number of litres of fuel left in the tank: ");
            double litresLeft = double.Parse(Console.ReadLine());

            // Constants are declared to represent the daily rate, petrol rate, booking fee, and the tank capacity.
            // Constants
            const int dailyRate = 25;
            const double petrolRate = 2.5;
            const int bookingFee = 10;
            const int tankCapacity = 50;

            // The total cost is calculated based on the given formula: totalCost = daysHired x dailyRate + (tankCapacity-LitresLeft) x pertolRate + bookingFee

            // Calculate total cost
            double totalCost = daysHired * dailyRate + (tankCapacity - litresLeft) * petrolRate + bookingFee;


            // The catch block handles the FormatException that may occur if the user enters non-numeric input. It prints an error message if an exception is caught.
            // Display the result
            Console.WriteLine($"The total charge for the car hire is £{totalCost:F2}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid input. Please enter a valid number for days and litres of fuel.");
        }
    }
}
