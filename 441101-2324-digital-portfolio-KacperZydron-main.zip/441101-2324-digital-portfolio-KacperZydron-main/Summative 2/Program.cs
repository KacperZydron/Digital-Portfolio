﻿using System;

class Program
{
    static void Main()
    {
        try
        {
            // This line prompts the user to enter the Digital Portfolio mark, reads the input as a string using Console.ReadLine(), and then converts it to an integer using int.Parse().
            // Get Digital Portfolio mark
            Console.Write("Enter Digital Portfolio Mark: ");
            int digitalPortfolioMark = int.Parse(Console.ReadLine());

            // The program checks whether the entered mark is valid using the IsValidMark method. If not, it displays an error message and exits the program.
            // Check if Digital Portfolio mark is valid
            if (!IsValidMark(digitalPortfolioMark))
            {
                Console.WriteLine($"{digitalPortfolioMark} is not a valid mark for the Digital Portfolio.");
                return;
            }

            // Get Open Book Programming Exam mark
            Console.Write("Enter Open Book Programming Exam Mark: ");
            int openBookExamMark = int.Parse(Console.ReadLine());

            // Check if Open Book Exam mark is valid
            if (!IsValidMark(openBookExamMark))
            {
                Console.WriteLine($"{openBookExamMark} is not a valid mark for the Open Book Programming Exam.");
                return;
            }

            // Get Capstone Project mark
            Console.Write("Enter Capstone Project Mark: ");
            int capstoneProjectMark = int.Parse(Console.ReadLine());

            // Check if Capstone Project mark is valid
            if (!IsValidMark(capstoneProjectMark))
            {
                Console.WriteLine($"{capstoneProjectMark} is not a valid mark for the Capstone Project.");
                return;
            }
            // The CalculatePercentage method is called to convert the raw mark to a percentage. It takes the marks awarded and the total available marks as arguments.
            // Calculate percentage marks for each element
            double digitalPortfolioPercentage = CalculatePercentage(digitalPortfolioMark, 35);
            double openBookExamPercentage = CalculatePercentage(openBookExamMark, 7);
            double capstoneProjectPercentage = CalculatePercentage(capstoneProjectMark, 100);

            // The overall module mark is calculated by multiplying each percentage by its weighting (50% for Digital Portfolio, 25% for Open Book Exam, and 25% for Capstone Project) and then summing them up.
            // Calculate overall module mark
            double overallModuleMark = (digitalPortfolioPercentage * 50 / 100) +
                                      (openBookExamPercentage * 25 / 100) +
                                      (capstoneProjectPercentage * 25 / 100);

            // If the Open Book Exam or Capstone Project percentages are less than 40, the overall module mark is capped at the minimum of the calculated mark or 34.
            // Cap overall module mark if needed
            if (openBookExamPercentage < 40 || capstoneProjectPercentage < 40)
            {
                overallModuleMark = Math.Min(overallModuleMark, 34);
            }
            // The DetermineClassification method is called to determine the degree classification based on the overall module mark.
            // Determine degree classification
            string degreeClassification = DetermineClassification(overallModuleMark);

            // Output the result
            Console.WriteLine($"Overall Module Mark: {overallModuleMark:F2}% - {degreeClassification}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid input. Please enter valid integer marks.");
        }
    }

    static bool IsValidMark(int mark)
    {
        return mark >= 0 && mark <= 35;
    }
    // This method calculates the percentage by dividing the marks awarded by the total available marks and multiplying by 100.
    static double CalculatePercentage(int marksAwarded, int totalAvailableMarks)
    {
        return (double)marksAwarded / totalAvailableMarks * 100;
    }
    // This method rounds the overall module mark to two decimal places and determines the degree classification based on the specified ranges.
    static string DetermineClassification(double overallModuleMark)
    {
        overallModuleMark = (float)Math.Round(overallModuleMark, 2);

        if (overallModuleMark >= 70)
        {
            return "1st";
        }
        else if (overallModuleMark >= 60)
        {
            return "2:1";
        }
        else if (overallModuleMark >= 50)
        {
            return "2:2";
        }
        else if (overallModuleMark >= 40)
        {
            return "3rd";
        }
        else
        {
            return "fail";
        }
    }
}
