# Practice Page

This page has been created for you to practice editing markdown. 

You should open the page with your instructions in one tab whilst you practice editing this page in another.
